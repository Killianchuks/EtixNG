package adapters;

public class mNotification_Adapter {
}
