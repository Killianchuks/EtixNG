package models.mJobs;

import androidx.annotation.Keep;

@Keep
public enum JobStatus {
    opened,
    closed,
    cancelled,
    disputed
}
