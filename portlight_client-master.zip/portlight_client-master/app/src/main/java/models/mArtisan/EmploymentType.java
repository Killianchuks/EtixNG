package models.mArtisan;

import androidx.annotation.Keep;

@Keep
public enum EmploymentType
{
    fullTime,
    partTime
}
