package models;

import androidx.annotation.Keep;

@Keep
public enum TabType {
    DEFAULT, ICON_TEXT, ICONS_ONLY, CUSTOM;
}